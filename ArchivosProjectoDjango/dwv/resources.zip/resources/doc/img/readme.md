# Architecture diagrams

Made using [PlantUML](https://plantuml.com/).

Images are generated with [planttext](https://www.planttext.com/).

nice page on class relations: [uml-class-diagram-relationships.html](http://usna86-techbits.blogspot.com/2012/11/uml-class-diagram-relationships.html)
