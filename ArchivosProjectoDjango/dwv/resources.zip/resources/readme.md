# Resources

- `doc`: dwv doc resources.
- `module`: javascript module scripts.
- `scripts`: apps and update scripts.
